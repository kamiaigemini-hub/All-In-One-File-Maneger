package com.allinone.filehub.features.explorer

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun CodeViewerDialog(
    file: File,
    onDismiss: () -> Unit
) {
    var codeContent by remember { mutableStateOf<CharSequence>("로딩 중...") }

    LaunchedEffect(file) {
        withContext(Dispatchers.IO) {
            val text = try {
                file.readText(Charsets.UTF_8)
            } catch (e: Exception) {
                "// 파일을 읽을 수 없습니다: ${e.localizedMessage}"
            }
            // 백그라운드에서 구문 강조 연산 후 반영
            codeContent = CodeHighlighter.highlight(text, file.extension.lowercase())
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false) // 전체화면 모달
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = MaterialTheme.shapes.large,
            color = Color(0xFF1E1F22) // 다크 에디터 배경색
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // 상단 타이틀 바
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = file.name,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium
                    )
                    TextButton(onClick = onDismiss) {
                        Text("닫기", color = Color(0xFF56A8F5))
                    }
                }

                HorizontalDivider(color = Color.DarkGray)

                // 코드 텍스트 영역 (가로/세로 스크롤 가능)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .horizontalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    Text(
                        text = codeContent as? androidx.compose.ui.text.AnnotatedString 
                            ?: androidx.compose.ui.text.AnnotatedString(codeContent.toString()),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = Color.LightGray
                    )
                }
            }
        }
    }
}
