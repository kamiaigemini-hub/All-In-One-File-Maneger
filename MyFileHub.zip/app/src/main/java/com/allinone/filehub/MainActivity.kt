package com.allinone.filehub

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.allinone.filehub.core.shizuku.ShizukuManager
import com.allinone.filehub.features.explorer.FileExplorerScreen
import com.allinone.filehub.features.font.FontInjectorDialog
import com.allinone.filehub.features.installer.ApkInstallerDialog
import com.allinone.filehub.features.installer.InstallerViewModel
import com.allinone.filehub.features.theme.ThemeDualScreen
import com.allinone.filehub.ui.components.CommonHeader
import com.allinone.filehub.ui.theme.FileHubTheme
import java.io.File

class MainActivity : ComponentActivity() {

    private val installerViewModel: InstallerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 저장소 전체 접근 권한 체크 및 요청
        checkStoragePermission()

        // Shizuku 권한 자동 요청
        if (ShizukuManager.isRunning() && !ShizukuManager.hasPermission()) {
            ShizukuManager.requestPermission { /* 권한 부여 콜백 */ }
        }

        setContent {
            FileHubTheme {
                MainAppScaffold(installerViewModel)
            }
        }
    }

    private fun checkStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }
    }
}

@Composable
fun MainAppScaffold(installerViewModel: InstallerViewModel) {
    var currentTab by remember { mutableIntStateOf(0) } // 0: 탐색기, 1: 테마 엔진
    var selectedFontFile by remember { mutableStateOf<File?>(null) }
    val installState by installerViewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            CommonHeader(
                title = "FileHub All-in-One",
                subtitle = if (currentTab == 0) "만능 파일 매니저" else "JSON 테마 & 자이로 엔진"
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    label = { Text("파일 탐색기") },
                    icon = { Text("📁") }
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    label = { Text("테마 스튜디오") },
                    icon = { Text("🎨") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> {
                    // 파일 탐색기 화면
                    FileExplorerScreen(
                        onFileSelected = { file ->
                            when (file.extension.lowercase()) {
                                "apk" -> {
                                    // APK 클릭 시 Shizuku 무인 인스톨러 팝업 호출
                                    installerViewModel.prepareInstall(file)
                                }
                                "ttf", "otf" -> {
                                    // 폰트 클릭 시 시스템 폰트 오버레이 주입 팝업 호출
                                    selectedFontFile = file
                                }
                            }
                        }
                    )
                }
                1 -> {
                    // JSON 테마 & 자이로 센서 화면
                    ThemeDualScreen()
                }
            }

            // 1. APK 인스톨러 다이얼로그
            ApkInstallerDialog(
                state = installState,
                onInstallClick = { file, appName ->
                    installerViewModel.startInstall(file, appName)
                },
                onDismiss = { installerViewModel.dismiss() }
            )

            // 2. 폰트 주입기 다이얼로그
            selectedFontFile?.let { font ->
                FontInjectorDialog(
                    fontFile = font,
                    onDismiss = { selectedFontFile = null }
                )
            }
        }
    }
}
