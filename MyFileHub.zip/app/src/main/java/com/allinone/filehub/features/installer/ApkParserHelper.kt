package com.allinone.filehub.features.installer

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import java.io.File

data class ApkMetadata(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val icon: Drawable?,
    val fileSizeBytes: Long
)

object ApkParserHelper {

    fun parseApk(context: Context, apkFile: File): ApkMetadata? {
        if (!apkFile.exists()) return null

        val pm = context.packageManager
        val packageInfo: PackageInfo? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageArchiveInfo(apkFile.absolutePath, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageArchiveInfo(apkFile.absolutePath, 0)
        } ?: return null

        val appInfo = packageInfo.applicationInfo ?: return null
        
        // 리소스 경로를 수동 지정해야 아이콘과 앱 이름을 정상 로드할 수 있음
        appInfo.sourceDir = apkFile.absolutePath
        appInfo.publicSourceDir = apkFile.absolutePath

        val appName = pm.getApplicationLabel(appInfo).toString()
        val icon = pm.getApplicationIcon(appInfo)
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            packageInfo.versionCode.toLong()
        }

        return ApkMetadata(
            appName = appName.ifEmpty { apkFile.nameWithoutExtension },
            packageName = packageInfo.packageName,
            versionName = packageInfo.versionName ?: "알 수 없음",
            versionCode = versionCode,
            icon = icon,
            fileSizeBytes = apkFile.length()
        )
    }
}
