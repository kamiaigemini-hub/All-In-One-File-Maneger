package com.allinone.filehub.features.font

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun FontInjectorDialog(
    fontFile: File,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isProcessing by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = {
            if (!isProcessing) onDismiss()
        },
        title = {
            Text(text = "시스템 폰트 적용기")
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(modifier = Modifier.size(44.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("더미 APK에 폰트를 주입하고 재서명하는 중...")
                } else if (statusMessage != null) {
                    Text(
                        text = statusMessage ?: "",
                        color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                } else {
                    Text(
                        text = "선택된 폰트: ${fontFile.name}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "이 폰트를 시스템 오버레이 패키지로 조립하여 Shizuku를 통해 즉시 무인 설치합니다.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            if (!isProcessing && statusMessage == null) {
                Button(onClick = {
                    isProcessing = true
                    scope.launch {
                        val result = OverlayBuilder.buildAndInjectFont(context, fontFile)
                        isProcessing = false
                        if (result.isSuccess) {
                            statusMessage = result.getOrNull()
                            isError = false
                        } else {
                            statusMessage = result.exceptionOrNull()?.message ?: "알 수 없는 오류"
                            isError = true
                        }
                    }
                }) {
                    Text("시스템 글꼴로 설치")
                }
            } else if (statusMessage != null) {
                Button(onClick = onDismiss) {
                    Text("확인")
                }
            }
        },
        dismissButton = {
            if (!isProcessing && statusMessage == null) {
                TextButton(onClick = onDismiss) {
                    Text("취소")
                }
            }
        }
    )
}
