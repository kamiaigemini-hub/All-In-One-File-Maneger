package com.allinone.filehub.features.explorer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.CompressionLevel
import net.lingala.zip4j.model.enums.CompressionMethod
import java.io.File

object ArchiveHelper {

    /**
     * 폴더나 단일 파일을 ZIP으로 압축
     */
    suspend fun zip(sourceFile: File, destinationZip: File): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val zipParameters = ZipParameters().apply {
                compressionMethod = CompressionMethod.DEFLATE
                compressionLevel = CompressionLevel.NORMAL
            }
            val zip = ZipFile(destinationZip)
            if (sourceFile.isDirectory) {
                zip.addFolder(sourceFile, zipParameters)
            } else {
                zip.addFile(sourceFile, zipParameters)
            }
        }
    }

    /**
     * ZIP 파일 압축 해제
     */
    suspend fun unzip(zipFile: File, destinationDir: File): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!destinationDir.exists()) {
                destinationDir.mkdirs()
            }
            val zip = ZipFile(zipFile)
            zip.extractAll(destinationDir.absolutePath)
        }
    }
}
