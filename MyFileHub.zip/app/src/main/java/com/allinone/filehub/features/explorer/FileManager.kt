package com.allinone.filehub.features.explorer

import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class FileItem(
    val file: File,
    val name: String,
    val isDirectory: Boolean,
    val sizeText: String,
    val extension: String
)

object FileManager {

    val rootStorage: File
        get() = Environment.getExternalStorageDirectory()

    /**
     * 디렉터리 내 파일 목록 정렬 (폴더 우선, 그 다음 이름순)
     */
    suspend fun listFiles(directory: File): List<FileItem> = withContext(Dispatchers.IO) {
        val files = directory.listFiles() ?: return@withContext emptyList()
        files.map { file ->
            val isDir = file.isDirectory
            val size = if (isDir) {
                "${file.list()?.size ?: 0} 항목"
            } else {
                formatFileSize(file.length())
            }
            FileItem(
                file = file,
                name = file.name,
                isDirectory = isDir,
                sizeText = size,
                extension = file.extension.lowercase()
            )
        }.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }

    suspend fun delete(file: File): Boolean = withContext(Dispatchers.IO) {
        if (file.isDirectory) file.deleteRecursively() else file.delete()
    }

    suspend fun rename(file: File, newName: String): Boolean = withContext(Dispatchers.IO) {
        val target = File(file.parentFile, newName)
        file.renameTo(target)
    }

    private fun formatFileSize(bytes: Long): String {
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format("%.2f GB", gb)
            mb >= 1.0 -> String.format("%.2f MB", mb)
            kb >= 1.0 -> String.format("%.1f KB", kb)
            else -> "$bytes B"
        }
    }
}
