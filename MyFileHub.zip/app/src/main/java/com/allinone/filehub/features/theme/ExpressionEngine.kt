package com.allinone.filehub.features.theme

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object ExpressionEngine {

    /**
     * 자이로 각도(pitch, roll) 값을 수식에 대입하여 실수값(Float)을 계산
     */
    fun evaluate(expression: String, pitch: Float, roll: Float, default: Float = 0f): Float {
        if (expression.isBlank()) return default

        return try {
            var expr = expression
                .replace("gyro.pitch", pitch.toString())
                .replace("gyro.roll", roll.toString())

            // 간단한 절대값 및 최대/최소 함수 지원
            if (expr.contains("Math.abs")) {
                val match = Regex("""Math\.abs\(([^)]+)\)""").find(expr)
                if (match != null) {
                    val innerVal = match.groupValues[1].toFloatOrNull() ?: 0f
                    expr = expr.replace(match.value, abs(innerVal).toString())
                }
            }

            // 기본 사칙연산 간이 파싱 (*, +, -, /)
            when {
                expr.contains("*") -> {
                    val parts = expr.split("*")
                    parts[0].trim().toFloat() * parts[1].trim().toFloat()
                }
                expr.contains("+") -> {
                    val parts = expr.split("+")
                    parts[0].trim().toFloat() + parts[1].trim().toFloat()
                }
                expr.contains("-") -> {
                    val parts = expr.split("-")
                    parts[0].trim().toFloat() - parts[1].trim().toFloat()
                }
                expr.contains("/") -> {
                    val parts = expr.split("/")
                    val divisor = parts[1].trim().toFloat()
                    if (divisor != 0f) parts[0].trim().toFloat() / divisor else default
                }
                else -> expr.trim().toFloatOrNull() ?: default
            }
        } catch (e: Exception) {
            default
        }
    }
}
