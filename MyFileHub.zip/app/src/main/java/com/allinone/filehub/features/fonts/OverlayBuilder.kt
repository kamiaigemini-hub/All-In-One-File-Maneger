package com.allinone.filehub.features.font

import android.content.Context
import com.allinone.filehub.core.shizuku.ShizukuManager
import com.allinone.filehub.features.installer.InstallResult
import com.allinone.filehub.features.installer.ShizukuPackageInstaller
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import java.io.File
import java.io.FileOutputStream

object OverlayBuilder {

    private const val DUMMY_APK_ASSET = "dummy_font.apk"

    /**
     * TTF 폰트를 더미 APK에 주입하고 서명한 뒤 Shizuku로 설치 진행
     */
    suspend fun buildAndInjectFont(
        context: Context,
        ttfFontFile: File
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cacheDir = context.cacheDir
            val tempDummyApk = File(cacheDir, "temp_dummy.apk")
            val targetSignedApk = File(cacheDir, "injected_font.apk")

            // 1. 에셋의 dummy_font.apk를 앱 내부 캐시로 복사
            context.assets.open(DUMMY_APK_ASSET).use { input ->
                FileOutputStream(tempDummyApk).use { output ->
                    input.copyTo(output)
                }
            }

            // 2. 사용자가 고른 폰트 파일을 dummy 내부 경로 규칙(fonts/custom.ttf)에 맞게 임시 복사
            val customTtf = File(cacheDir, "custom.ttf")
            ttfFontFile.copyTo(customTtf, overwrite = true)

            // 3. Zip4j를 사용해 dummy APK 내부의 assets/fonts/custom.ttf 위치에 폰트 덮어쓰기
            val zip = ZipFile(tempDummyApk)
            val zipParameters = ZipParameters().apply {
                fileNameInZip = "assets/fonts/custom.ttf"
            }
            zip.addFile(customTtf, zipParameters)

            // 4. 서명 갱신
            val signResult = ApkSignerHelper.signApk(tempDummyApk, targetSignedApk)
            if (signResult.isFailure) {
                throw Exception("APK 재서명 실패: ${signResult.exceptionOrNull()?.message}")
            }

            // 임시 파일 청소
            tempDummyApk.delete()
            customTtf.delete()

            // 5. Shizuku를 통해 무인 설치 실행
            if (!ShizukuManager.isRunning() || !ShizukuManager.hasPermission()) {
                throw Exception("Shizuku 권한이 없거나 서비스가 실행 중이지 않습니다.")
            }

            when (val installRes = ShizukuPackageInstaller.installApk(targetSignedApk)) {
                is InstallResult.Success -> {
                    targetSignedApk.delete()
                    "폰트 오버레이 설치 완료! 시스템 글꼴 설정에서 변경할 수 있습니다."
                }
                is InstallResult.Failure -> {
                    targetSignedApk.delete()
                    throw Exception("무인 설치 실패: ${installRes.message}")
                }
            }
        }
    }
}
