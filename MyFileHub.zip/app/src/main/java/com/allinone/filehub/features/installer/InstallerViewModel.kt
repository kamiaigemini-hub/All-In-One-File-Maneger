package com.allinone.filehub.features.installer

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.allinone.filehub.core.shizuku.ShizukuManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed class InstallUiState {
    data object Idle : InstallUiState()
    data class Ready(val metadata: ApkMetadata, val apkFile: File) : InstallUiState()
    data object Installing : InstallUiState()
    data class Success(val appName: String) : InstallUiState()
    data class Error(val message: String) : InstallUiState()
}

class InstallerViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow<InstallUiState>(InstallUiState.Idle)
    val uiState: StateFlow<InstallUiState> = _uiState.asStateFlow()

    /**
     * 탐색기에서 APK 파일을 탭했을 때 메타데이터를 파싱하고 준비 상태로 전환
     */
    fun prepareInstall(apkFile: File) {
        val metadata = ApkParserHelper.parseApk(getApplication(), apkFile)
        if (metadata != null) {
            _uiState.value = InstallUiState.Ready(metadata, apkFile)
        } else {
            _uiState.value = InstallUiState.Error("유효하지 않거나 손상된 APK 파일입니다.")
        }
    }

    /**
     * Shizuku 무인 설치 실행
     */
    fun startInstall(apkFile: File, appName: String) {
        if (!ShizukuManager.isRunning()) {
            _uiState.value = InstallUiState.Error("Shizuku가 실행 중이지 않습니다. Shizuku 앱을 먼저 실행해 주세요.")
            return
        }

        if (!ShizukuManager.hasPermission()) {
            ShizukuManager.requestPermission { granted ->
                if (granted) {
                    startInstall(apkFile, appName)
                } else {
                    _uiState.value = InstallUiState.Error("Shizuku 권한이 거부되었습니다.")
                }
            }
            return
        }

        _uiState.value = InstallUiState.Installing

        viewModelScope.launch {
            when (val result = ShizukuPackageInstaller.installApk(apkFile)) {
                is InstallResult.Success -> {
                    _uiState.value = InstallUiState.Success(appName)
                }
                is InstallResult.Failure -> {
                    _uiState.value = InstallUiState.Error(result.message)
                }
            }
        }
    }

    fun dismiss() {
        _uiState.value = InstallUiState.Idle
    }
}
