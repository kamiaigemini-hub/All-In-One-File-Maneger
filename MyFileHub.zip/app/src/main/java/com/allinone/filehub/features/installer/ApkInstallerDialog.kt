package com.allinone.filehub.features.installer

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import java.io.File

@Composable
fun ApkInstallerDialog(
    state: InstallUiState,
    onInstallClick: (File, String) -> Unit,
    onDismiss: () -> Unit
) {
    if (state is InstallUiState.Idle) return

    AlertDialog(
        onDismissRequest = {
            if (state !is InstallUiState.Installing) onDismiss()
        },
        title = {
            Text(
                text = when (state) {
                    is InstallUiState.Ready -> "애플리케이션 설치"
                    is InstallUiState.Installing -> "무인 설치 중..."
                    is InstallUiState.Success -> "설치 완료"
                    is InstallUiState.Error -> "설치 실패"
                    else -> ""
                }
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (state) {
                    is InstallUiState.Ready -> {
                        state.metadata.icon?.let { drawable ->
                            Image(
                                bitmap = drawable.toBitmap(width = 160, height = 160).asImageBitmap(),
                                contentDescription = "App Icon",
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                        Text(text = state.metadata.appName, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "패키지: ${state.metadata.packageName}", style = MaterialTheme.typography.bodySmall)
                        Text(text = "버전: ${state.metadata.versionName} (${state.metadata.versionCode})", style = MaterialTheme.typography.bodySmall)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Shizuku 백그라운드 권한으로 무인 설치를 진행합니다.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    is InstallUiState.Installing -> {
                        CircularProgressIndicator(modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("패키지를 설치하고 있습니다. 잠시만 기다려 주세요...")
                    }
                    is InstallUiState.Success -> {
                        Text("🎉 '${state.appName}' 앱이 성공적으로 설치되었습니다!")
                    }
                    is InstallUiState.Error -> {
                        Text("오류 내용:\n${state.message}", color = MaterialTheme.colorScheme.error)
                    }
                    else -> Unit
                }
            }
        },
        confirmButton = {
            when (state) {
                is InstallUiState.Ready -> {
                    Button(onClick = { onInstallClick(state.apkFile, state.metadata.appName) }) {
                        Text("무인 설치")
                    }
                }
                is InstallUiState.Success, is InstallUiState.Error -> {
                    Button(onClick = onDismiss) {
                        Text("확인")
                    }
                }
                else -> Unit
            }
        },
        dismissButton = {
            if (state is InstallUiState.Ready) {
                TextButton(onClick = onDismiss) {
                    Text("취소")
                }
            }
        }
    )
}
