package com.allinone.filehub.core.shizuku

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

data class CommandResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String
) {
    val isSuccess: Boolean get() = exitCode == 0
}

object ShellExecutor {

    /**
     * Shizuku 권한으로 셸 명령어를 백그라운드에서 실행
     */
    suspend fun execute(command: String): CommandResult = withContext(Dispatchers.IO) {
        if (!ShizukuManager.hasPermission()) {
            return@withContext CommandResult(-1, "", "Shizuku 권한이 없습니다.")
        }

        try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)

            val stdoutReader = BufferedReader(InputStreamReader(process.inputStream))
            val stderrReader = BufferedReader(InputStreamReader(process.errorStream))

            val stdout = StringBuilder()
            val stderr = StringBuilder()

            stdoutReader.forEachLine { line -> stdout.appendLine(line) }
            stderrReader.forEachLine { line -> stderr.appendLine(line) }

            val exitCode = process.waitFor()

            CommandResult(
                exitCode = exitCode,
                stdout = stdout.toString().trim(),
                stderr = stderr.toString().trim()
            )
        } catch (e: Exception) {
            CommandResult(-1, "", e.localizedMessage ?: "알 수 없는 오류 발생")
        }
    }
}
