package com.allinone.filehub.ui.theme

import androidx.compose.ui.graphics.Color

// 메인 브랜드 포인트 컬러 (사이버 블루 & 네온 악센트)
val PrimaryNeon = Color(0xFF38BDF8)
val PrimaryVariant = Color(0xFF0284C7)
val AccentPink = Color(0xFFF43F5E)

// 배경 및 서피스 다크 계열
val BackgroundDark = Color(0xFF131417)
val SurfaceDark = Color(0xFF1E1F22)
val SurfaceVariantDark = Color(0xFF2B2D30)

// 텍스트 & 테두리 컬러
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val BorderSubtle = Color(0xFF334155)
