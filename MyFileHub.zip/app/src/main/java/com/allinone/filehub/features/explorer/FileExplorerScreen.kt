package com.allinone.filehub.features.explorer

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun FileExplorerScreen(
    onFileSelected: (File) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var currentDir by remember { mutableStateOf(FileManager.rootStorage) }
    var fileItems by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    
    // 길게 눌렀을 때 메뉴 띄울 파일 상태
    var contextMenuFile by remember { mutableStateOf<File?>(null) }
    // 코드 뷰어에 띄울 파일 상태
    var viewingCodeFile by remember { mutableStateOf<File?>(null) }

    val scope = rememberCoroutineScope()

    fun refresh(target: File) {
        scope.launch {
            fileItems = FileManager.listFiles(target)
        }
    }

    LaunchedEffect(currentDir) {
        refresh(currentDir)
    }

    BackHandler(enabled = currentDir != FileManager.rootStorage && currentDir.parentFile != null) {
        currentDir.parentFile?.let { currentDir = it }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(currentDir.name.ifEmpty { "내부 저장소" }) },
                navigationIcon = {
                    if (currentDir != FileManager.rootStorage && currentDir.parentFile != null) {
                        TextButton(onClick = { currentDir.parentFile?.let { currentDir = it } }) {
                            Text("← 상위")
                        }
                    }
                }
            )
        },
        modifier = modifier
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            items(fileItems, key = { it.file.absolutePath }) { item ->
                Box {
                    ListItem(
                        headlineContent = { Text(item.name) },
                        supportingContent = { Text(item.sizeText) },
                        leadingContent = {
                            Text(
                                text = if (item.isDirectory) "📁" else when (item.extension) {
                                    "zip", "7z", "tar" -> "📦"
                                    "apk" -> "📱"
                                    "ttf", "otf" -> "🔤"
                                    "json", "kt", "java", "xml", "txt" -> "📄"
                                    else -> "📄"
                                },
                                style = MaterialTheme.typography.headlineSmall
                            )
                        },
                        modifier = Modifier.combinedClickable(
                            onClick = {
                                if (item.isDirectory) {
                                    currentDir = item.file
                                } else {
                                    onFileSelected(item.file)
                                }
                            },
                            onLongClick = {
                                if (!item.isDirectory) {
                                    contextMenuFile = item.file // 롱클릭 시 메뉴 오픈
                                }
                            }
                        )
                    )

                    // 길게 눌렀을 때 뜨는 드롭다운 메뉴
                    DropdownMenu(
                        expanded = contextMenuFile == item.file,
                        onDismissRequest = { contextMenuFile = null }
                    ) {
                        DropdownMenuItem(
                            text = { Text("코드로 열기 (하이라이트)") },
                            onClick = {
                                viewingCodeFile = item.file
                                contextMenuFile = null
                            }
                        )
                    }
                }
                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
            }
        }
    }

    // 코드 뷰어 팝업 열기
    viewingCodeFile?.let { file ->
        CodeViewerDialog(
            file = file,
            onDismiss = { viewingCodeFile = null }
        )
    }
}
