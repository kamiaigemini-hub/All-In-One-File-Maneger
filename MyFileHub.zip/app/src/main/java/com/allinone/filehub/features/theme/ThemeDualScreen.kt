package com.allinone.filehub.features.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.allinone.filehub.core.sensor.GyroData
import com.allinone.filehub.core.sensor.GyroscopeManager
import com.google.gson.Gson
import com.google.gson.GsonBuilder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeDualScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val gson: Gson = remember { GsonBuilder().setPrettyPrinting().create() }
    val gyroManager = remember { GyroscopeManager(context) }
    val gyroState by gyroManager.gyroData.collectAsState()

    // 센서 생명주기 관리
    DisposableEffect(Unit) {
        gyroManager.start()
        onDispose { gyroManager.stop() }
    }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: 시각적 UI, 1: JSON 텍스트 에디터
    var currentTheme by remember {
        // assets/default_theme.json 로드
        val initialJson = try {
            context.assets.open("default_theme.json").bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            "{}"
        }
        mutableStateOf(gson.fromJson(initialJson, ThemeModel::class.java) ?: ThemeModel())
    }

    var jsonEditorText by remember { mutableStateOf(gson.toJson(currentTheme)) }
    var jsonSyntaxError by remember { mutableStateOf<String?>(null) }

    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        // 상단 탭 전환
        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("일반 UI 모드") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("개발자 JSON 모드") })
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 실시간 자이로 반응형 테마 미리보기 박스
        ThemePreviewBox(theme = currentTheme, gyroData = gyroState)

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == 0) {
            // [일반 사용자 모드]: 슬라이더와 토글 버튼
            Text("카드 둥글기: ${currentTheme.ui.cardRadius.toInt()} dp")
            Slider(
                value = currentTheme.ui.cardRadius,
                onValueChange = { newRadius ->
                    val updated = currentTheme.copy(ui = currentTheme.ui.copy(cardRadius = newRadius))
                    currentTheme = updated
                    jsonEditorText = gson.toJson(updated)
                },
                valueRange = 0f..40f
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("자이로 센서 활성화")
                Spacer(modifier = Modifier.weight(1f))
                Switch(
                    checked = currentTheme.gyroscope.enabled,
                    onCheckedChange = { enabled ->
                        val updated = currentTheme.copy(gyroscope = currentTheme.gyroscope.copy(enabled = enabled))
                        currentTheme = updated
                        jsonEditorText = gson.toJson(updated)
                    }
                )
            }
        } else {
            // [개발자 텍스트 코딩 모드]: 실시간 문법 검사 에디터
            OutlinedTextField(
                value = jsonEditorText,
                onValueChange = { newText ->
                    jsonEditorText = newText
                    try {
                        val parsed = gson.fromJson(newText, ThemeModel::class.java)
                        if (parsed != null) {
                            currentTheme = parsed
                            jsonSyntaxError = null
                        }
                    } catch (e: Exception) {
                        jsonSyntaxError = "JSON 문법 오류: ${e.message}"
                    }
                },
                modifier = Modifier.fillMaxWidth().weight(1f),
                label = { Text("Theme JSON Spec") }
            )

            jsonSyntaxError?.let { error ->
                Text(
                    text = error,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun ThemePreviewBox(theme: ThemeModel, gyroData: GyroData) {
    // 자이로 수식 평가
    val tiltX = if (theme.gyroscope.enabled) {
        ExpressionEngine.evaluate(theme.gyroscope.expressions["cardTiltX"] ?: "gyro.pitch * 0.5", gyroData.pitch, gyroData.roll)
    } else 0f

    val tiltY = if (theme.gyroscope.enabled) {
        ExpressionEngine.evaluate(theme.gyroscope.expressions["cardTiltY"] ?: "gyro.roll * 0.5", gyroData.pitch, gyroData.roll)
    } else 0f

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .graphicsLayer {
                rotationX = tiltX
                rotationY = tiltY
                cameraDistance = 12f * density
            },
        shape = RoundedCornerShape(theme.ui.cardRadius.dp),
        colors = CardDefaults.cardColors(
            containerColor = try {
                Color(android.graphics.Color.parseColor(theme.colors.primary))
            } catch (e: Exception) {
                MaterialTheme.colorScheme.primary
            }
        )
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = theme.themeName,
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "기울기: P(${gyroData.pitch.toInt()}°), R(${gyroData.roll.toInt()}°)",
                    color = Color.White.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
