package com.allinone.filehub.features.theme

import com.google.gson.annotations.SerializedName

data class ThemeModel(
    @SerializedName("themeName") var themeName: String = "Default Theme",
    @SerializedName("version") var version: String = "1.0.0",
    @SerializedName("author") var author: String = "User",
    @SerializedName("colors") var colors: ThemeColors = ThemeColors(),
    @SerializedName("ui") var ui: ThemeUi = ThemeUi(),
    @SerializedName("gyroscope") var gyroscope: ThemeGyroscope = ThemeGyroscope()
)

data class ThemeColors(
    @SerializedName("primary") var primary: String = "#38BDF8",
    @SerializedName("background") var background: String = "#1E1F22",
    @SerializedName("surface") var surface: String = "#2B2D30",
    @SerializedName("accent") var accent: String = "#F43F5E",
    @SerializedName("text") var text: String = "#F8FAFC"
)

data class ThemeUi(
    @SerializedName("cardRadius") var cardRadius: Float = 16.0f,
    @SerializedName("elevation") var elevation: Float = 4.0f,
    @SerializedName("fontFamily") var fontFamily: String = "Roboto",
    @SerializedName("blurEffect") var blurEffect: Boolean = true
)

data class ThemeGyroscope(
    @SerializedName("enabled") var enabled: Boolean = true,
    @SerializedName("sensitivity") var sensitivity: Float = 1.0f,
    @SerializedName("maxTiltAngle") var maxTiltAngle: Float = 45.0f,
    @SerializedName("expressions") var expressions: Map<String, String> = emptyMap()
)
