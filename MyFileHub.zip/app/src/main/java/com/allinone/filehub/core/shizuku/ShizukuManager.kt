package com.allinone.filehub.core.shizuku

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuManager {

    private const val REQUEST_CODE = 1001

    /**
     * Shizuku 바인더 서비스가 폰에서 살아있는지 확인
     */
    fun isRunning(): Boolean {
        return Shizuku.pingBinder()
    }

    /**
     * Shizuku 권한이 허용되어 있는지 확인
     */
    fun hasPermission(): Boolean {
        return if (isRunning()) {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } else {
            false
        }
    }

    /**
     * Shizuku 권한 요청 팝업 띄우기
     */
    fun requestPermission(onRequestResult: (Boolean) -> Unit) {
        if (!isRunning()) {
            onRequestResult(false)
            return
        }

        if (hasPermission()) {
            onRequestResult(true)
            return
        }

        // 권한 결과 리스너 등록
        val listener = object : Shizuku.OnRequestPermissionResultListener {
            override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                if (requestCode == REQUEST_CODE) {
                    Shizuku.removeRequestPermissionResultListener(this)
                    onRequestResult(grantResult == PackageManager.PERMISSION_GRANTED)
                }
            }
        }

        Shizuku.addRequestPermissionResultListener(listener)
        Shizuku.requestPermission(REQUEST_CODE)
    }
}
