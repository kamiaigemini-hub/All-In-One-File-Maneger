package com.allinone.filehub.core.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * 실시간 센서 상태 데이터 클래스
 * @param pitch X축 기준 앞뒤 기울기 (단위: 도 -90 ~ 90)
 * @param roll Y축 기준 좌우 기울기 (단위: 도 -180 ~ 180)
 * @param yaw Z축 회전 각속도 또는 방향
 * @param isGyroAvailable 기기에 물리 자이로스코프 센서가 있는지 여부
 */
data class GyroData(
    val pitch: Float = 0f,
    val roll: Float = 0f,
    val yaw: Float = 0f,
    val isGyroAvailable: Boolean = false
)

class GyroscopeManager(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    // 물리 자이로스코프 센서 우선 확인
    private val gyroSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    // 대체용 가속도계 센서
    private val accelSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val _gyroData = MutableStateFlow(
        GyroData(isGyroAvailable = gyroSensor != null)
    )
    val gyroData: StateFlow<GyroData> = _gyroData.asStateFlow()

    private var isListening = false
    private var lastUpdateTime: Long = 0
    private val updateIntervalNs: Long = 16_000_000 // 약 16ms (60fps 제한으로 배터리 보호)

    // 가속도계 기반 각도 적분/계산용 임시 값
    private var currentPitch = 0f
    private var currentRoll = 0f

    /**
     * 센서 리스너 등록 시작
     */
    fun start() {
        if (isListening) return

        val targetSensor = gyroSensor ?: accelSensor
        if (targetSensor != null) {
            // UI 부드러움에 적합한 SENSOR_DELAY_UI로 등록
            sensorManager.registerListener(this, targetSensor, SensorManager.SENSOR_DELAY_UI)
            isListening = true
        }
    }

    /**
     * 센서 리스너 중지 (백그라운드 진입 시 호출 필수)
     */
    fun stop() {
        if (!isListening) return
        sensorManager.unregisterListener(this)
        isListening = false
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        val now = event.timestamp
        // 60fps 이상으로 빈번하게 호출되는 이벤트는 스킵
        if (now - lastUpdateTime < updateIntervalNs) return
        lastUpdateTime = now

        if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            // 자이로스코프: 각속도(rad/s)가 들어오므로 각도 단위로 환산 보정
            val axisX = event.values[0] // pitch 방향
            val axisY = event.values[1] // roll 방향
            val axisZ = event.values[2] // yaw 방향

            // 간이 각도 누적 및 리미트 (-90 ~ 90 범위로 안전 클램핑)
            currentPitch = (currentPitch + axisX * 2f).coerceIn(-90f, 90f)
            currentRoll = (currentRoll + axisY * 2f).coerceIn(-90f, 90f)

            _gyroData.value = GyroData(
                pitch = currentPitch,
                roll = currentRoll,
                yaw = axisZ,
                isGyroAvailable = true
            )
        } else if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            // 가속도계 대체 모드: 중력 방향을 이용해 기울기 각도 직접 역산
            val ax = event.values[0]
            val ay = event.values[1]
            val az = event.values[2]

            // 삼각함수로 기울기 각도(degree) 계산
            val pitch = (atan2(ay.toDouble(), sqrt((ax * ax + az * az).toDouble())) * (180.0 / Math.PI)).toFloat()
            val roll = (atan2(-ax.toDouble(), az.toDouble()) * (180.0 / Math.PI)).toFloat()

            _gyroData.value = GyroData(
                pitch = pitch,
                roll = roll,
                yaw = 0f,
                isGyroAvailable = false // 물리 자이로는 없음을 명시
            )
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // 정확도 변경 시 특별한 조치 불필요
    }
}
