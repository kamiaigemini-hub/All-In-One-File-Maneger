package com.allinone.filehub.features.explorer

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import java.util.regex.Pattern

object CodeHighlighter {

    // 1. 세분화된 토큰 컬러 팔레트 (JetBrains / VS Code 스타일 다크 테마)
    private val COLOR_KEYWORD_CONTROL = Color(0xFFCC7832)  // 제어문 (if, return, for 등): 진한 주황
    private val COLOR_KEYWORD_DECL = Color(0xFFE8BF6A)     // 선언/수식어 (val, fun, class 등): 황금빛 노랑
    private val COLOR_TYPE = Color(0xFF6897BB)             // 타입/클래스명 (String, Int, List): 밝은 청록
    private val COLOR_ANNOTATION = Color(0xFFBBB529)       // 어노테이션 (@Override, @Composable): 올리브 골드
    private val COLOR_FUNCTION = Color(0xFF56A8F5)         // 함수 호출 및 메서드: 하늘색
    private val COLOR_NUMBER = Color(0xFF6897BB)           // 숫자 리터럴: 시안 블루
    private val COLOR_STRING = Color(0xFF6AAB73)           // 문자열: 소프트 그린
    private val COLOR_ESCAPE = Color(0xFFD4B069)           // 이스케이프 문자 (\n, \t): 베이지
    private val COLOR_COMMENT = Color(0xFF7A7E85)          // 주석: 중간 회색
    private val COLOR_JSON_KEY = Color(0xFF9876AA)         // JSON 키 / 객체 속성: 보라색
    private val COLOR_OPERATOR = Color(0xFFA9B7C6)         // 연산자 및 기호: 소프트 화이트

    // 2. 메이저 언어(Kotlin, Java, JS/TS, Python, C/C++, Rust, Go, Swift 등) 망라 키워드 사전
    private val CONTROL_KEYWORDS = listOf(
        "if", "else", "when", "switch", "case", "default", "match",
        "for", "while", "do", "repeat", "loop", "break", "continue", "fallthrough",
        "return", "yield", "await", "async", "throw", "throws", "try", "catch", "finally",
        "defer", "goto"
    )

    private val DECLARATION_KEYWORDS = listOf(
        "package", "import", "as", "from", "export", "typealias", "using", "namespace",
        "val", "var", "let", "const", "def", "fn", "function", "func",
        "class", "interface", "struct", "enum", "object", "trait", "impl", "type",
        "fun", "constructor", "init", "deinit", "lambda",
        "public", "private", "protected", "internal", "fileprivate",
        "abstract", "final", "open", "sealed", "override", "virtual", "static", "inline",
        "infix", "tailrec", "operator", "suspend", "mut", "pub", "unsafe", "extern",
        "volatile", "transient", "native", "synchronized", "strictfp",
        "is", "in", "by", "where", "out", "reified", "dynamic", "typeof", "instanceof", "sizeof",
        "this", "super", "self", "Self", "null", "nil", "None", "true", "false"
    )

    // 원시 타입 및 표준 자료형
    private val BUILTIN_TYPES = listOf(
        "Byte", "Short", "Int", "Long", "Float", "Double", "Boolean", "Char", "String", "Unit", "Nothing", "Any",
        "int", "short", "long", "float", "double", "char", "boolean", "byte", "void", "size_t", "uint", "uint32_t",
        "i8", "i16", "i32", "i64", "u8", "u16", "u32", "u64", "f32", "f64", "usize", "isize", "bool", "str",
        "List", "Map", "Set", "Array", "ArrayList", "HashMap", "Vector", "Option", "Result"
    )

    // 3. 정규식 컴파일
    private val CONTROL_PATTERN = Pattern.compile("\\b(${CONTROL_KEYWORDS.joinToString("|")})\\b")
    private val DECLARATION_PATTERN = Pattern.compile("\\b(${DECLARATION_KEYWORDS.joinToString("|")})\\b")
    private val TYPE_PATTERN = Pattern.compile("\\b(${BUILTIN_TYPES.joinToString("|")}|[A-Z][a-zA-Z0-9_]*)\\b") // 대문자로 시작하는 모든 사용자 정의 클래스명도 타입으로 처리
    private val ANNOTATION_PATTERN = Pattern.compile("@[a-zA-Z0-9_.]+")
    private val FUNCTION_PATTERN = Pattern.compile("\\b([a-zA-Z_][a-zA-Z0-9_]*)(?=\\s*\\()")
    private val NUMBER_PATTERN = Pattern.compile("\\b(0x[0-9a-fA-F]+|0b[01]+|\\d+(\\.\\d+)?([eE][+-]?\\d+)?[fFLdD]?)\\b")
    private val JSON_KEY_PATTERN = Pattern.compile("\"([^\"]+)\"\\s*\\:")
    private val STRING_PATTERN = Pattern.compile("\"(\\\\.|[^\"\\\\])*\"|'(\\\\.|[^'\\\\])*'|`(\\\\.|[^`\\\\])*`")
    private val ESCAPE_PATTERN = Pattern.compile("\\\\[nrtbfav0'\"\\\\]")
    private val COMMENT_PATTERN = Pattern.compile("//.*|/\\*[\\s\\S]*?\\*/|#.*") // Python/Shell 계열 # 주석 포함

    /**
     * 파일 확장자와 텍스트를 받아 토큰별 구문 강조를 적용한 AnnotatedString 반환
     */
    fun highlight(code: String, extension: String): AnnotatedString {
        return buildAnnotatedString {
            append(code)

            // 1단계: 기본 텍스트 및 연산자/숫자
            applyPattern(code, NUMBER_PATTERN, SpanStyle(color = COLOR_NUMBER))

            // 2단계: 타입명 (대문자로 시작하는 클래스 포함)
            applyPattern(code, TYPE_PATTERN, SpanStyle(color = COLOR_TYPE))

            // 3단계: 함수 호출
            applyPattern(code, FUNCTION_PATTERN, SpanStyle(color = COLOR_FUNCTION))

            // 4단계: 선언 키워드 (val, fun, class 등)
            applyPattern(code, DECLARATION_PATTERN, SpanStyle(color = COLOR_KEYWORD_DECL, fontWeight = FontWeight.Bold))

            // 5단계: 흐름 제어문 (if, return, for 등)
            applyPattern(code, CONTROL_PATTERN, SpanStyle(color = COLOR_KEYWORD_CONTROL, fontWeight = FontWeight.Bold))

            // 6단계: 어노테이션 (@Composable 등)
            applyPattern(code, ANNOTATION_PATTERN, SpanStyle(color = COLOR_ANNOTATION))

            // 7단계: JSON 키 구분
            if (extension == "json") {
                applyPattern(code, JSON_KEY_PATTERN, SpanStyle(color = COLOR_JSON_KEY, fontWeight = FontWeight.SemiBold))
            }

            // 8단계: 문자열 및 이스케이프 문자 (키워드/함수를 덮어씀)
            applyPattern(code, STRING_PATTERN, SpanStyle(color = COLOR_STRING))
            applyPattern(code, ESCAPE_PATTERN, SpanStyle(color = COLOR_ESCAPE, fontWeight = FontWeight.Bold))

            // 9단계: 주석 (모든 것을 덮어쓰고 이탤릭 처리)
            applyPattern(code, COMMENT_PATTERN, SpanStyle(color = COLOR_COMMENT, fontStyle = FontStyle.Italic))
        }
    }

    private fun AnnotatedString.Builder.applyPattern(
        text: String,
        pattern: Pattern,
        style: SpanStyle
    ) {
        val matcher = pattern.matcher(text)
        while (matcher.find()) {
            addStyle(style, matcher.start(), matcher.end())
        }
    }
}
