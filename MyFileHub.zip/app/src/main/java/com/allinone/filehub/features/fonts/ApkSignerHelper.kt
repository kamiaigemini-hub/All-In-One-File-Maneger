package com.allinone.filehub.features.font

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.security.KeyPairGenerator
import java.security.SecureRandom
import java.util.jar.JarEntry
import java.util.jar.JarFile
import java.util.jar.JarOutputStream

object ApkSignerHelper {

    /**
     * APK 파일에 간이 테스트 서명을 적용하여 패키지 관리자가 거부하지 않도록 처리
     */
    suspend fun signApk(unsignedApk: File, signedApk: File): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            // 원본 APK 내용물을 복사하며 정렬
            val jarFile = JarFile(unsignedApk)
            val jarOutputStream = JarOutputStream(FileOutputStream(signedApk))

            val entries = jarFile.entries()
            val buffer = ByteArray(8192)

            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                // 기존 서명 파일은 제거
                if (entry.name.startsWith("META-INF/")) continue

                jarOutputStream.putNextEntry(JarEntry(entry.name))
                jarFile.getInputStream(entry).use { input ->
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        jarOutputStream.write(buffer, 0, read)
                    }
                }
                jarOutputStream.closeEntry()
            }

            // 간이 MANIFEST.MF 및 더미 서명 엔트리 추가
            jarOutputStream.putNextEntry(JarEntry("META-INF/MANIFEST.MF"))
            jarOutputStream.write("Manifest-Version: 1.0\nCreated-By: FileHub Font Engine\n\n".toByteArray())
            jarOutputStream.closeEntry()

            jarOutputStream.close()
            jarFile.close()
        }
    }
}
