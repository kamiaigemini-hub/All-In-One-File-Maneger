# Gson 룰
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn com.google.gson.**
-keep class com.allinone.filehub.features.theme.** { *; }

# Shizuku 리플렉션 보존
-keep class rikka.shizuku.** { *; }
